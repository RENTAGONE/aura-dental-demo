# Rebuild prompt for new demo sites (v1.2)

**How to use (about 2 minutes per demo):**
1. Open a **new chat** in this project. One chat per demo keeps it fast and cheap.
2. Attach `aura-medical-flagship.zip` (the full project zip).
3. Paste the prompt below, fill every `[BRACKET]`, send.
4. Revamp of an existing client site? Paste that site's text and the Google info raw into the CLIENT block.

Photos can always be added after: drop files into `public/images/` (filenames in README.md). Nothing else changes.

---

## THE PROMPT (copy everything in this block)

```
You are an elite Staff Frontend Engineer and UI/UX art director (Next.js App Router, TypeScript strict with zero `any`, Tailwind, Framer Motion, lucide-react). I attached aura-medical-flagship.zip. Use it as an ENGINEERING BASE and a library of ready sections to build a NEW demo for a different business.

MODE: ADD-ON, NOT A COPY
- Keep and reuse the infrastructure: bilingual system (bi()), splash, language popup, Photo with art fallbacks, CSS-variable theme tokens, EMI/cost calculator (adapt to the client's services), lead API, triage widget, mobile action bar, routing.
- Do NOT ship a recolour. First write your visual direction in 5 short lines: concept, hero archetype, signature interaction, type pairing, motion personality. Then build it. You may rewrite, delete or add any section or component to serve that direction. Go beyond the template: new layouts, new motion ideas, new details the Aura demo does not have.
- It must look clearly different from Aura and from my other demos while staying equally premium. Think 100,000 BDT agency work: rich scroll-reveal motion on every section, many imagery slots, many real pages, zero thin or "mid" pages.

CLIENT
- Business name, niche, area/city: [..]
- Services with BDT price ranges (low to high, and whether per tooth / session / case / month): [..]
- Team: names, roles, years of experience: [..]
- Phone, WhatsApp number, address, opening hours, consultation fee: [..]
- What the client said and info scraped from Google (paste raw): [..]
- Revamp only: current website text and sections (paste raw). Stay true to its facts, make it far better: [..]

LOOK
- Palette: [0, A to I from the palette list, or "design one for this niche"]. Reskin only through the :root block in app/globals.css, themeColor in app/layout.tsx and app/icon.svg. Never hardcode colours. Keep text contrast at 4.5:1 or better.
- Hero archetype (pick one that is NOT Aura's arch-photo hero): full-bleed cinematic photo with overlaid type / oversized typographic hero with floating cut-outs / diagonal split / bento grid hero / interactive before-after hero / your own idea.
- Signature interaction for the treatments or services area. Starting points in the zip: components/TreatmentStage.tsx (pinned vertical scroll stage with progress rail) and components/TreatmentExplorer.tsx (tabbed explorer). Pick a DIFFERENT one from my other demos, or invent a new one: smile/face hotspot diagram, sticky stacking cards, expanding image accordion, interactive process rail. Rule: obviously interactive (clear affordance, progress indicator, 48px tap targets), works on mobile, never a horizontal scroll-jack.
- Type: choose a new display + body pairing that suits the niche (keep a Bangla-capable fallback such as Noto Serif Bengali or Hind Siliguri).

DO NOT REGRESS (already fixed in the template)
1. The splash plays on EVERY page refresh: no sessionStorage or localStorage skip. Fade in, hold 1.5 seconds, slide up (ease 0.76, 0, 0.24, 1).
2. Stat counters use the Counter in components/Reveal.tsx (IntersectionObserver + scroll listener + requestAnimationFrame). Never framer-motion's useInView + animate for counters. They must work on mobile.
3. Bangla is the default on every load. A popup appears 3 seconds after the splash: "Viewing in Bangla. Translate to English?" with English and Cancel.
4. The triage widget stays button-only and deterministic. Do not change its logic or routing. I will integrate my own triage engine later.
5. All copy is bilingual through bi(). Bangla line-height 1.3 or more so vowel signs are not clipped. Never put Bangla inside overflow-hidden boxes without vertical padding.
6. The contact form keeps posting to /api/lead (honeypot, fill-time trap, BD phone validation, spam filter, rate limit, scoring).

RULES
- Prices, names, reviews and claims are demo content unless I supplied them. Do not present invented certifications as fact for a real client; keep them editable in lib/data.ts and lib/site.ts.
- Mobile first: 48px tap targets, no horizontal overflow, sticky mobile action bar.
- Animate only transform and opacity where possible. Respect prefers-reduced-motion.
- Code first, minimal explanation. Ask nothing unless something blocks the build; state assumptions in one line.

DELIVER
- Two zips, files at the top level with no wrapping folder: (1) changed-files-only, (2) the full project. List any deleted files in CHANGES.txt inside the changed-files zip.
- A numbered list of the exact photo filenames I need to add under public/images/.
- Run a syntax check on every file before zipping and tell me honestly what could not be tested.
```

---

## PALETTES (paste the block into `:root` in `app/globals.css`)

Token names are legacy: `ink` is the dark base, `lagoon` is the cool accent, `brass` is the warm accent (buttons, highlights), `porcelain` is the light section background. Values are R G B channels. Want something else? Tell the chat "design a custom palette for [niche]" and it will follow the same 13 tokens.

### 0. Lagoon & Brass (the Aura original)
Best for: medical, dental, clinics. Also set `themeColor` in `app/layout.tsx` to `#06171B` and recolour the 3 hex values in `app/icon.svg`.
```css
:root {
  --ink-950: 6 23 27;
  --ink-900: 10 36 41;
  --ink-800: 15 49 56;
  --ink-700: 23 69 77;
  --lagoon-300: 138 218 210;
  --lagoon-400: 79 195 188;
  --lagoon-500: 31 163 163;
  --lagoon-600: 22 133 135;
  --brass-200: 240 221 176;
  --brass-300: 228 201 138;
  --brass-400: 212 174 99;
  --brass-500: 185 143 69;
  --porcelain: 243 247 246;
}
```

### A. Midnight Navy & Champagne
Best for: premium dental, medical, corporate clinics. Also set `themeColor` in `app/layout.tsx` to `#0A1128` and recolour the 3 hex values in `app/icon.svg`.
```css
:root {
  --ink-950: 10 17 40;
  --ink-900: 16 26 58;
  --ink-800: 24 37 79;
  --ink-700: 36 55 104;
  --lagoon-300: 169 199 245;
  --lagoon-400: 123 167 236;
  --lagoon-500: 74 127 214;
  --lagoon-600: 53 99 181;
  --brass-200: 243 230 200;
  --brass-300: 232 210 160;
  --brass-400: 216 184 116;
  --brass-500: 184 150 79;
  --porcelain: 244 246 250;
}
```

### B. Rose Quartz & Espresso
Best for: skin, aesthetics, salon, beauty. Also set `themeColor` in `app/layout.tsx` to `#1E1412` and recolour the 3 hex values in `app/icon.svg`.
```css
:root {
  --ink-950: 30 20 18;
  --ink-900: 43 29 26;
  --ink-800: 60 42 37;
  --ink-700: 85 57 47;
  --lagoon-300: 244 201 196;
  --lagoon-400: 233 166 160;
  --lagoon-500: 217 127 122;
  --lagoon-600: 185 93 90;
  --brass-200: 243 220 196;
  --brass-300: 232 195 158;
  --brass-400: 214 161 115;
  --brass-500: 180 126 82;
  --porcelain: 250 244 241;
}
```

### C. Forest & Sand
Best for: wellness, organic, family clinics, physiotherapy. Also set `themeColor` in `app/layout.tsx` to `#0B1A14` and recolour the 3 hex values in `app/icon.svg`.
```css
:root {
  --ink-950: 11 26 20;
  --ink-900: 17 38 29;
  --ink-800: 26 58 44;
  --ink-700: 38 80 64;
  --lagoon-300: 191 224 200;
  --lagoon-400: 140 198 160;
  --lagoon-500: 79 165 116;
  --lagoon-600: 58 129 89;
  --brass-200: 242 230 201;
  --brass-300: 230 210 163;
  --brass-400: 210 182 120;
  --brass-500: 173 145 82;
  --porcelain: 244 247 242;
}
```

### D. Plum & Pearl
Best for: women's health, luxury clinics, fertility, dermatology. Also set `themeColor` in `app/layout.tsx` to `#170B1F` and recolour the 3 hex values in `app/icon.svg`.
```css
:root {
  --ink-950: 23 11 31;
  --ink-900: 34 17 46;
  --ink-800: 50 25 63;
  --ink-700: 71 36 90;
  --lagoon-300: 224 195 242;
  --lagoon-400: 199 153 230;
  --lagoon-500: 168 111 208;
  --lagoon-600: 134 80 174;
  --brass-200: 246 231 198;
  --brass-300: 236 211 160;
  --brass-400: 220 183 112;
  --brass-500: 184 147 75;
  --porcelain: 248 244 250;
}
```

### E. Graphite & Copper
Best for: orthodontics, grooming, premium minimal. Also set `themeColor` in `app/layout.tsx` to `#0F1012` and recolour the 3 hex values in `app/icon.svg`.
```css
:root {
  --ink-950: 15 16 18;
  --ink-900: 23 25 28;
  --ink-800: 34 38 43;
  --ink-700: 51 57 65;
  --lagoon-300: 207 216 224;
  --lagoon-400: 163 178 192;
  --lagoon-500: 118 144 166;
  --lagoon-600: 88 113 134;
  --brass-200: 246 220 195;
  --brass-300: 235 191 152;
  --brass-400: 219 155 104;
  --brass-500: 184 120 67;
  --porcelain: 244 245 246;
}
```

### F. Ocean & Coral
Best for: family and kids' dentistry, friendly clinics. Also set `themeColor` in `app/layout.tsx` to `#051A24` and recolour the 3 hex values in `app/icon.svg`.
```css
:root {
  --ink-950: 5 26 36;
  --ink-900: 10 42 56;
  --ink-800: 16 59 77;
  --ink-700: 26 80 104;
  --lagoon-300: 168 230 240;
  --lagoon-400: 98 207 227;
  --lagoon-500: 34 174 203;
  --lagoon-600: 26 139 165;
  --brass-200: 255 217 207;
  --brass-300: 255 187 168;
  --brass-400: 255 149 124;
  --brass-500: 224 112 90;
  --porcelain: 242 248 250;
}
```

### G. Olive & Brass
Best for: heritage, herbal, ayurvedic, wellness retreats. Also set `themeColor` in `app/layout.tsx` to `#14170E` and recolour the 3 hex values in `app/icon.svg`.
```css
:root {
  --ink-950: 20 23 14;
  --ink-900: 29 34 20;
  --ink-800: 42 49 29;
  --ink-700: 58 68 40;
  --lagoon-300: 214 227 165;
  --lagoon-400: 183 204 114;
  --lagoon-500: 147 174 72;
  --lagoon-600: 114 138 51;
  --brass-200: 240 222 176;
  --brass-300: 226 197 126;
  --brass-400: 205 166 82;
  --brass-500: 166 131 54;
  --porcelain: 246 246 238;
}
```

### H. Burgundy & Gold
Best for: traditional luxury, bridal, high-end aesthetics. Also set `themeColor` in `app/layout.tsx` to `#1C0A10` and recolour the 3 hex values in `app/icon.svg`.
```css
:root {
  --ink-950: 28 10 16;
  --ink-900: 42 16 25;
  --ink-800: 61 24 36;
  --ink-700: 87 34 47;
  --lagoon-300: 241 196 207;
  --lagoon-400: 226 147 166;
  --lagoon-500: 203 102 128;
  --lagoon-600: 166 71 99;
  --brass-200: 245 226 179;
  --brass-300: 234 208 138;
  --brass-400: 219 182 92;
  --brass-500: 184 146 61;
  --porcelain: 250 244 243;
}
```

### I. Ink Blue & Mint
Best for: tech-forward clinics, diagnostics, labs, hospitals. Also set `themeColor` in `app/layout.tsx` to `#070F1A` and recolour the 3 hex values in `app/icon.svg`.
```css
:root {
  --ink-950: 7 15 26;
  --ink-900: 13 26 43;
  --ink-800: 20 40 64;
  --ink-700: 30 58 92;
  --lagoon-300: 182 242 220;
  --lagoon-400: 111 227 189;
  --lagoon-500: 47 196 149;
  --lagoon-600: 31 157 119;
  --brass-200: 255 239 201;
  --brass-300: 255 224 160;
  --brass-400: 255 201 107;
  --brass-500: 224 162 60;
  --porcelain: 242 247 247;
}
```

---

## CHANGELOG

- v1.2: home signature section is now a pinned scroll stage (scroll up/down or tap the rail), counters fixed for mobile too, prompt rewritten as add-on mode with 10 palettes.
- v1.1: tabbed explorer, splash on every refresh, colours moved to CSS variables.
