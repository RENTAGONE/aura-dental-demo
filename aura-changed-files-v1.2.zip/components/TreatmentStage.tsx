"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion, useMotionValueEvent, useScroll, useTransform, type Variants } from "framer-motion";
import { ArrowRight, Check, ChevronDown } from "lucide-react";
import { bi, taka } from "@/lib/i18n";
import { cn } from "@/lib/cn";
import { TREATMENTS } from "@/lib/data";
import { useLang } from "./Providers";
import { Photo } from "./Photo";
import { SOFT } from "./Reveal";

const EASE: [number, number, number, number] = [0.76, 0, 0.24, 1];
/** Decorative ring text. Edit this per client. */
const RING = "Implants • Aligners • Veneers • Root canal • Whitening • Skin • ";

/** Smoothly tweens a number towards its target (used for the live price). */
function useTween(target: number, ms = 800): number {
  const [v, setV] = useState(target);
  const from = useRef(target);
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { from.current = target; setV(target); return; }
    const start = from.current;
    const t0 = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min((now - t0) / ms, 1);
      const val = start + (target - start) * (1 - Math.pow(1 - p, 3));
      from.current = val;
      setV(val);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, ms]);
  return v;
}

const reveal: Variants = {
  enter: (d: number) => ({ clipPath: d > 0 ? "inset(100% 0% 0% 0%)" : "inset(0% 0% 100% 0%)" }),
  center: { clipPath: "inset(0% 0% 0% 0%)", transition: { duration: 0.95, ease: EASE } },
  exit: { opacity: 1, transition: { duration: 0.95 } },
};
const group: Variants = {
  enter: {},
  center: { transition: { staggerChildren: 0.08, delayChildren: 0.15 } },
  exit: { opacity: 0, transition: { duration: 0.25 } },
};
const item: Variants = {
  enter: (d: number) => ({ opacity: 0, y: 34 * d }),
  center: { opacity: 1, y: 0, transition: { duration: 0.7, ease: SOFT } },
};

/**
 * Pinned scroll stage: scroll down/up to step through treatments, or tap the rail to jump.
 * Vertical only, always with a progress rail, so it never feels like scroll-hijacking.
 */
export function TreatmentStage() {
  const { tr, lang } = useLang();
  const wrap = useRef<HTMLElement>(null);
  const n = TREATMENTS.length;
  const [i, setI] = useState(0);
  const iRef = useRef(0);
  const dir = useRef(1);

  const { scrollYProgress } = useScroll({ target: wrap, offset: ["start start", "end end"] });
  useMotionValueEvent(scrollYProgress, "change", (p) => {
    const next = Math.min(n - 1, Math.max(0, Math.floor(p * n)));
    if (next !== iRef.current) { dir.current = next > iRef.current ? 1 : -1; iRef.current = next; setI(next); }
  });

  const jump = (idx: number) => {
    const el = wrap.current;
    if (!el) return;
    const top = el.getBoundingClientRect().top + window.scrollY;
    const total = el.offsetHeight - window.innerHeight;
    window.scrollTo({ top: top + ((idx + 0.5) / n) * total, behavior: "smooth" });
  };

  const t = TREATMENTS[i];
  const d = dir.current;
  const fromV = useTween(t.from);
  const toV = useTween(t.to);
  const ringRot = useTransform(scrollYProgress, [0, 1], [0, 320]);
  const glowX = useTransform(scrollYProgress, [0, 1], ["-10%", "40%"]);
  const numeral = (i + 1).toLocaleString(lang === "bn" ? "bn-BD" : "en-US", { minimumIntegerDigits: 2 });

  return (
    <section ref={wrap} id="treatments" style={{ height: `${n * 75 + 100}svh` }} className="relative bg-ink-950 text-white">
      <div className="grain sticky top-0 h-[100svh] overflow-hidden">
        <motion.div style={{ x: glowX }} className="pointer-events-none absolute -left-24 top-1/4 h-[32rem] w-[32rem] rounded-full bg-lagoon-500/20 blur-3xl" />
        <div className="pointer-events-none absolute -right-24 bottom-0 h-[28rem] w-[28rem] rounded-full bg-brass-400/15 blur-3xl" />

        <div className="relative mx-auto flex h-full max-w-7xl flex-col px-5 pb-4 pt-20 sm:px-8 lg:pt-24">
          <header className="flex items-end justify-between gap-4">
            <h2 className="text-[clamp(1.6rem,3.2vw,2.8rem)] font-medium">{tr(bi("আমাদের ট্রিটমেন্টসমূহ", "Our treatments"))}</h2>
            <p className="flex items-center gap-2 pb-1 text-sm text-white/60"><ChevronDown className="h-4 w-4 animate-bounce text-brass-300" />{tr(bi("স্ক্রল করুন বা ট্যাপ করুন", "Scroll or tap"))}</p>
          </header>

          <div className="grid min-h-0 flex-1 items-center gap-3 lg:grid-cols-[1.05fr_0.95fr_auto] lg:gap-10">
            <div className="order-2 lg:order-1" aria-live="polite">
              <p className="hidden font-display text-[8rem] leading-none text-transparent [-webkit-text-stroke:1px_rgb(255_255_255/0.2)] lg:block" aria-hidden>{numeral}<span className="text-4xl [-webkit-text-stroke:0] text-white/30"> / {n.toLocaleString(lang === "bn" ? "bn-BD" : "en-US", { minimumIntegerDigits: 2 })}</span></p>
              <AnimatePresence mode="wait" initial={false}>
                <motion.div key={t.slug} variants={group} initial="enter" animate="center" exit="exit">
                  <motion.h3 variants={item} custom={d} className="text-[clamp(1.6rem,3.6vw,3.2rem)] font-medium">{tr(t.name)}</motion.h3>
                  <motion.p variants={item} custom={d} className="mt-2 line-clamp-2 max-w-md text-white/70 lg:mt-4 lg:line-clamp-none">{tr(t.short)}</motion.p>
                  <motion.p variants={item} custom={d} className="mt-3 font-display text-2xl text-brass-300 lg:mt-5 lg:text-3xl">{taka(fromV, lang)} – {taka(toV, lang)} <span className="font-sans text-sm text-white/55">{tr(t.unit)}</span></motion.p>
                  <motion.ul variants={item} custom={d} className="mt-5 hidden space-y-2 md:block">
                    {t.benefits.map((b) => <li key={b.en} className="flex gap-3 text-white/80"><Check className="mt-1 h-4 w-4 shrink-0 text-emerald-300" />{tr(b)}</li>)}
                  </motion.ul>
                  <motion.div variants={item} custom={d} className="mt-4 flex flex-wrap gap-3 lg:mt-7">
                    <Link href={`/treatments/${t.slug}`} className="btn-brass">{tr(bi("বিস্তারিত দেখুন", "See details"))}<ArrowRight className="h-4 w-4" /></Link>
                    <Link href="/pricing#calculator" className="btn-ghost hidden sm:inline-flex">{tr(bi("খরচ হিসাব করুন", "Estimate cost"))}</Link>
                  </motion.div>
                </motion.div>
              </AnimatePresence>
            </div>

            <div className="relative order-1 mx-auto aspect-[4/5] h-[31svh] lg:order-2 lg:h-[62svh]">
              <div className="absolute -inset-3 translate-x-3 translate-y-3 rounded-t-[999px] rounded-b-[2rem] border border-brass-300/40" />
              <div className="relative h-full w-full overflow-hidden rounded-t-[999px] rounded-b-[2rem] bg-ink-800 ring-1 ring-white/15">
                <AnimatePresence initial={false} custom={d}>
                  <motion.div key={t.slug} custom={d} variants={reveal} initial="enter" animate="center" exit="exit" className="absolute inset-0">
                    <motion.div initial={{ scale: 1.25 }} animate={{ scale: 1 }} transition={{ duration: 1.4, ease: SOFT }} className="h-full w-full">
                      <Photo src={t.image} alt={tr(t.name)} art={t.art} className="h-full w-full" />
                    </motion.div>
                  </motion.div>
                </AnimatePresence>
              </div>
              <motion.div style={{ rotate: ringRot }} className="absolute -right-5 -top-5 h-20 w-20 text-brass-300 lg:-right-9 lg:-top-8 lg:h-28 lg:w-28" aria-hidden>
                <svg viewBox="0 0 120 120" className="h-full w-full">
                  <defs><path id="stage-ring" d="M60,60 m-44,0 a44,44 0 1,1 88,0 a44,44 0 1,1 -88,0" /></defs>
                  <text fontSize="8.5" fill="currentColor" textLength="270" lengthAdjust="spacingAndGlyphs"><textPath href="#stage-ring">{RING}</textPath></text>
                </svg>
              </motion.div>
            </div>

            <nav aria-label={tr(bi("ট্রিটমেন্ট", "Treatments"))} className="relative order-3 flex justify-center lg:flex-col lg:pl-6">
              <div className="absolute bottom-3 left-0 top-3 hidden w-px bg-white/15 lg:block"><motion.div style={{ scaleY: scrollYProgress }} className="h-full origin-top bg-brass-300" /></div>
              {TREATMENTS.map((x, idx) => (
                <button key={x.slug} onClick={() => jump(idx)} aria-label={tr(x.name)} aria-current={idx === i}
                  className={cn("flex min-h-12 min-w-9 items-center justify-center gap-3 rounded-full px-2 text-sm transition-colors lg:min-h-11 lg:justify-start", idx === i ? "text-white" : "text-white/45 hover:text-white")}>
                  <span className={cn("h-2 w-2 shrink-0 rounded-full transition-transform duration-300", idx === i ? "scale-150 bg-brass-300" : "bg-white/40")} />
                  <span className="hidden max-w-[13rem] truncate whitespace-nowrap lg:inline">{tr(x.name)}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>
      </div>
    </section>
  );
}
